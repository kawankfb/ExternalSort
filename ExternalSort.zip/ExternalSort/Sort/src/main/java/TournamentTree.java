import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

public class TournamentTree {
    static int leafCount;
    static int initialLeafCount;
    TournamentTree(int height,int leafCount){
        TournamentTree.leafCount=leafCount;
        initialLeafCount=leafCount;
        Node node = new Node(height);
        try {
            PrintWriter pw =new PrintWriter("sorted.txt");
                while (node.notFinished){
                    pw.println(node.getMin());
                }
                pw.flush();
                pw.close();
            for (int i = 0; i <initialLeafCount ; i++) {
                Files.deleteIfExists(Paths.get(i + ".txt"));
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
