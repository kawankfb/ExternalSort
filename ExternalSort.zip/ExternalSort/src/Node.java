public class Node {
    Node right;
    Node left;
    boolean answered=false;
    long answer;
    boolean notFinished =false;
    Node (){
    notFinished=true;
    }
    Node (int height){
        if (TournamentTree.leafCount>0)
            notFinished =true;
            if (height>1)
            {right =new Node(height-1);
            }
            else  {
                right=new Leaf(TournamentTree.leafCount);
                TournamentTree.leafCount--;
            }
            if (height>1)
            {left =new Node(height-1);
            }
            else  {
                left=new Leaf(TournamentTree.leafCount);
                TournamentTree.leafCount--;
            }


    }
    public long getMin(){
        if (answered){
            answered=false;
            return answer;}
        if (right.notFinished || right.answered) {
            long minRight=right.getMin();
            right.answer=minRight;
            right.answered=true;
            if (left.notFinished || left.answered) {
                long minLeft=left.getMin();
                left.answer=minLeft;
                left.answered=true;
                if (minLeft<minRight)
                {
                    left.answered=false;
                    return minLeft;}
                else {
                    right.answered=false;
                    return minRight;}
            }
            else {
                if (!(right.notFinished))
                    notFinished =false;
                right.answered=false;
                return minRight;
            }
        }
        else if (left.notFinished || left.answered)
        {long minLeft=left.getMin();
            if (!(left.notFinished))
                notFinished =false;
            left.answered=false;
        return minLeft;
        }
        else notFinished=false;
        return 1;
    }
}
