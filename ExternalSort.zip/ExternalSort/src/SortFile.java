import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;
public class SortFile {
    static FileInputStream fos;
    static Scanner scanner;
    static final int liaf=128_000_000; //longs in a file
    public static void main(String[] args) {
        try {
            fos = new FileInputStream("a.txt");
            scanner = new Scanner(fos);
            int sfc=0; // Secondary File count
            while (scanner.hasNextLong()){
                long numbers[]=new long[liaf];
                int i;
                for (i = 0; i <liaf && scanner.hasNextLong() ; i++) {
                    numbers[i]=scanner.nextLong();
                }
                Arrays.parallelSort(numbers,0,i);
                PrintWriter pw =new PrintWriter(sfc+".txt");
                sfc++;
                for (int j = 0; j <i ; j++) {
                 pw.println(numbers[j]);
                }
                pw.flush();
                pw.close();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        int ntf=0;//number of temporary files
        while(Files.exists(Paths.get(ntf + ".txt")))
        ntf++;

        int height=1;
        for (int i = 1; i <ntf ; i=i*2) {
            height++;
        }
        TournamentTree tt=new TournamentTree(height,ntf);
    }
}
