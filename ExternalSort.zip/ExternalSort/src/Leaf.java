import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Leaf extends Node {
    long[] A;
    int read;
    Scanner scanner;
    int finishPoint=-2;
    Leaf(int leaf){
        if (leaf>0) {
            read = 0;
            int ilc = TournamentTree.initialLeafCount;
            A = new long[(128_000_000 / ilc)];
            try {
                FileInputStream fis = new FileInputStream(ilc - leaf + ".txt");
                scanner = new Scanner(fis);
                int i;
                for (i = 0; i < A.length &&scanner.hasNextLong(); i++) {
                    A[i]=scanner.nextLong();
                }
                if (!scanner.hasNextLong())
                    finishPoint=i%A.length;

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        else notFinished=false;
    }
    @Override
    public long getMin(){
        if (answered){
            answered=false;
            return answer;}
            answer = A[read];
        if ((read+1)%A.length==finishPoint){
            notFinished=false;
            scanner.close();
        }else if (scanner.hasNextLong())
                  A[read]=scanner.nextLong();
              else if (finishPoint==-2)
                  finishPoint=read;

        read=(read+1)%A.length;

        return answer;
    }

}
